create table Universite (
    id_univ integer primary key,
    nom_univ varchar(50),
    adresse_univ varchar(255),
    site_web_univ varchar(255),
    tel_univ varchar(20)
);

create table Faculte (
    id_fac integer primary key,
    nom_fac varchar(50),
    adresse_fac varchar(255),
    tel_fac varchar(20),
    id_univ integer,
    foreign key (id_univ) references Universite(id_univ)
);

create table JPO (
    id_jpo integer primary key,
    date_jpo date,
    horaire_jpo time,
    ville_jpo varchar(50),
    code_postal_jpo char(5),
    departement_jpo varchar(50)
);

create table Formation (
    id_formation integer primary key,
    nom_formation varchar(100),
    duree_formation integer,
    id_fac integer,
    foreign key (id_fac) references Faculte(id_fac)
);

create table Prerequis (
    id_prerequis integer primary key,
    anne_etude integer,
    type_bac varchar(50),
    necessite_concours boolean,
    id_formation integer,
    foreign key (id_formation) references Formation(id_formation)
);

create table Matiere (
    id_matiere integer primary key,
    nom_matiere varchar(50),
    coef_matiere integer,
    id_formation integer,
    foreign key (id_formation) references Formation(id_formation)
);

create table Niveau (
    id_niveau integer primary key,
    nom_niveau varchar(50),
    id_matiere integer,
    foreign key (id_matiere) references Matiere(id_matiere)
);